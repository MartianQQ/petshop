public interface Pet {
	public void setName (String n);
	public void setColor (String c);
	public void setAge (int a);
	public String getName ();
	public String getColor ();
	public int getAge ();
}