import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class Main{
    public static PetShop PS = new PetShop ();
    public static void main (String args[]) {
        LoginWindow lw = new LoginWindow ();
    }
}
